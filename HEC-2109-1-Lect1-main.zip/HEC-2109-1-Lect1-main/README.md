# HEC-2109-1-Lect1

Contains material and python code needed for HEC Class Two Week Python Module in September 2021

Click here to run in mybinder:
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/jvkrogmeier/HEC-2109-1-Lect1/HEAD)
